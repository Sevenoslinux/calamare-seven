Settings for Calamares installer, including default file system change to btrfs and option to disable fsync.

Configurações para o instalador Calamares, incluindo a troca do sistema arquivos padrão para btrfs e opção de desativar o fsync.

![01](https://user-images.githubusercontent.com/6098501/178167123-89282bf6-6cbd-4604-a6da-76daa38a4b5a.jpeg)
![02](https://user-images.githubusercontent.com/6098501/178167127-10b52634-ca84-472a-b564-5f046b262445.jpeg)
